<?php get_header();?>
<section id="banner" class="banner--sm">
			<h2 class="banner--heading banner--heading-emphasis banner--sm-heading">
				Oops
			</h2>
			<p class="banner--tagline">
				The page you are looking for does not exist
			</p>
		</section>
<main>
    <section class="section section--four04">
		<div class="box">
			<img class="four04--image" src="https://http.cat/404" alt="404-not-found">
		</div>
	</section>
</main>

<?php get_footer();?>